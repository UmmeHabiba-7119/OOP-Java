
package mathlearningtool;

import java.text.DecimalFormat;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class LearnMath {
    Scanner input = new Scanner(System.in);
    int score=0;
    String summary ="";
    public void sumLearn(){
        int num1 = (int)(Math.random()*20);
        int num2 = (int)(Math.random()*20);
        int actualAnswer = num1+num2;
        int userAnswer=Integer.parseInt(JOptionPane.showInputDialog("What is "+num1+"+"+num2+"?:"));
        //int userAnswer = input.nextInt();
        if(actualAnswer==userAnswer){
            score++;
        }
        summary = summary+"\n"+num1+"+"+num2+"="+userAnswer+":"+(actualAnswer==userAnswer);
    }
    public void subLearn(){
        int num1 = (int)(Math.random()*20);
        int num2 = (int)(Math.random()*20);
        if(num1<num2){
            int temp = num1;
            num1 = num2;
            num2 = temp;
        }
        int actualAnswer = num1-num2;
         int userAnswer=Integer.parseInt(JOptionPane.showInputDialog("What is "+num1+"-"+num2+"?:"));
        //int userAnswer = input.nextInt();
        if(actualAnswer==userAnswer){
            score+=1;
        }
        summary = summary+"\n"+num1+"-"+num2+"="+userAnswer+":"+(actualAnswer==userAnswer);
    }
    public void multipleLearn(){
        int num1 = (int)(Math.random()*20);
        int num2 = (int)(Math.random()*20);
        int actualAnswer = num1*num2;
         int userAnswer=Integer.parseInt(JOptionPane.showInputDialog("What is "+num1+"*"+num2+"?:"));
        //int userAnswer = input.nextInt();
        if(actualAnswer==userAnswer){
            score=score+1;
        }
        summary = summary+"\n"+num1+"*"+num2+"="+userAnswer+":"+(actualAnswer==userAnswer);
    }
    public void divisionLearn(){
        double num1 = (int)(Math.random()*20);
        double num2 = (int)(Math.random()*20);
        if(num1==0.0 || num1==1.0 || num2==0.0 || num2==1.0){
            num1=num1+2;
            num2=num2+2;
        }
        if(num1<num2){
            double temp = num1;
            num1 = num2;
            num2 = temp;
        }
        double actualAnswer = num1/num2;
        DecimalFormat df = new DecimalFormat("#.##");
        String s = df.format(actualAnswer);
        actualAnswer = Double.valueOf(s);
        double userAnswer=Double.parseDouble(JOptionPane.showInputDialog("What is "+(int)num1+"/"+(int)num2+"?:"));
        //double userAnswer = input.nextDouble();
        if(actualAnswer==userAnswer){
            score++;
        }
         summary = summary+"\n"+(int)num1+"/"+(int)num2+"="+userAnswer+":"+(actualAnswer==userAnswer);
    }
    
}
