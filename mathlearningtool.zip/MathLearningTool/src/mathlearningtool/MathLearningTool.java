
package mathlearningtool;

import java.util.Scanner;
import javax.swing.JOptionPane;


public class MathLearningTool {

  
    public void randomPlay() {
        Scanner input = new Scanner(System.in);
        LearnMath lm = new LearnMath();
        int qnum=Integer.parseInt(JOptionPane.showInputDialog(null,"How many question do you want?"));
        
        long startTime = System.currentTimeMillis();
        for(int i=0; i<qnum; i++){
            int rm = (int)(Math.random()*4);
            switch(rm){
                case 0:
                    lm.sumLearn();
                    break;
                case 1:
                    lm.subLearn();
                    break;
                case 2:
                    lm.multipleLearn();
                    break;
                default:
                    lm.divisionLearn();
                    break;
            }
        }
        
        long endTime = System.currentTimeMillis();
        long totalTime = endTime-startTime;
        JOptionPane.showMessageDialog(null,"Your score is "+lm.score+"\nTotal time taken "+totalTime/1000+" seconds"+"\nSummary: "+lm.summary);
        
    }
    
}
