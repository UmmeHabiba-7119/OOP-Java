
package algorithmarray;

import java.util.Scanner;


public class AlgorithmArray {

  
    public static void main(String[] args) {
     
      Scanner input = new Scanner(System.in);
        int x;
        int signal = 0;
        int search;
        
      System.out.println("How many numbers do you want? ");
       x = input.nextInt();
       int[] array = new int[x];
       
       System.out.println("Enter your array numbers ");
       
      for(int i = 0; i<array.length; i++){
          array[i] = input.nextInt();
      }
      
      System.out.println("Enter the number you want to search\n");
      search = input.nextInt();
      
      for(int i = 0; i<array.length; i++)
      {
          if(array[i]==search)
          {
              System.out.println("Yes!! Match the number in location "+i);
              signal = 1;
             
          }
      }
    
      
          if(signal==0)
          {
              System.out.println("Sorry!! Do not match");
          
      }
    }
    
}
