 
 
package resturants;

 
public class Resturants {

   
    public static void main(String[] args) {
        NewJFrame1 n1=new NewJFrame1();
        n1.setVisible(true);
       
    }
    
}
